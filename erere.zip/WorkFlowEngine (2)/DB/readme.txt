The order of execution of scripts:
1. CreatePersistenceObjects.sql
2. CreateObjects.sql
3. FillData.sql